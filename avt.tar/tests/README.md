# tests

This folder contains all tests performed during test phase of the project. EICAR test file included.
