# logs

This is a folder dedicated to test process log storage.

Filename format: test_yyyymmdd_HHMMSS.log