#pragma once

#include <string>

struct Results
{
    int status;
    int elapsed = -1;
    std::string detected = "";
};